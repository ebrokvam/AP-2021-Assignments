module Warmup where

{-# OPTIONS_GHC -W #-}  -- Just in case you forgot...


type Pos = (Int, Int)
data Direction = North | South | East | West

move :: Direction -> Pos -> Pos
move North (x,y) = (x, y+1)
move West  (x,y) = (x-1, y)
move South (x,y) = (x,y-1)
move East (x,y) = (x+1,y)
-- complete the definition

moves :: [Direction] -> Pos -> Pos
moves [] pos = pos
moves (h:hs) pos = moves hs (move h pos)
-- replace with actual definition of moves, and likewise for the
-- other 'undefined' functions

data Nat = Zero | Succ Nat
  deriving (Eq, Show, Read, Ord)

add :: Nat -> Nat -> Nat
add Zero n = n
add n Zero = n
add (Succ n1) (Succ n2) = add (Succ(Succ n1)) n2


mult :: Nat -> Nat -> Nat 
mult n1 n2 = mult' Zero n1 n2 

mult' :: Nat -> Nat -> Nat -> Nat 
mult' x1 _ Zero = x1
mult' x1 x2 (Succ n2) = mult' (add x1 x2) x2 n2


-- convert from Nat to Int
nat2int :: Nat -> Int 
nat2int Zero = 0
nat2int (Succ n) = 1 + nat2int n

-- convert from Int to Nat
int2nat :: Int -> Nat
int2nat 0 = Zero
int2nat n = Succ (int2nat $ n-1) 


data Tree = Leaf | Node Int Tree Tree
  deriving (Eq, Show, Read, Ord)

insert :: Int -> Tree -> Tree
-- call recursively until find right place for int and place it if not there yet
insert x Leaf = Node x Leaf Leaf
insert x (Node y t1 t2) 
  | x == y = Node y t1 t2
  | x > y  = Node y t1 (insert x t2)
  | x < y  = Node y (insert x t1) t2


{-
Change the declaration of Tree so that it is polymorphic in the data 
stored in the nodes. What happens to the type of the function insert?
-}
-- The polymorphic variant, to avoid name clashes with the above
data PTree a = PLeaf | PNode a (PTree a) (PTree a)

pinsert :: Ord a => a -> (PTree a) -> (PTree a) 
pinsert x PLeaf = PNode x PLeaf PLeaf
pinsert x t@(PNode y l r)
  | x > y  = PNode y l (pinsert x r)
  | x < y  = PNode y (pinsert x l) r
  | x == y = PNode y l r