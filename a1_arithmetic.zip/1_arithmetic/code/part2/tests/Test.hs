-- Very rudimentary test of Arithmetic. Feel free to replace completely

import Definitions
import Arithmetic

import Data.List (intercalate)
import System.Exit (exitSuccess, exitFailure)  -- for when running stand-alone

tests :: [(String, Bool)]
tests = [test00, 
         test01, 
         test02, 
         test03,
         test04,
         test05,
         test06,
         test07] where
  test00 = ("test00_showExp", showExp (Mul (Cst 2) (Add (Cst 3) (Cst 4))) == "((2)*((3)+(4)))")
  test01 = ("test01_showExp", showExp (Add (Div (Cst 15) (Cst 3)) (Cst 9)) == "(((15)`div`(3))+(9))")

  -- simple evaluation test --
  test02 = ("test02_evalSimple_Add", evalSimple (Add (Cst 2) (Cst 2)) == 4)
  test03 = ("test03_evalSimple_Sub", evalSimple (Sub (Cst 44) (Cst 2)) == 42)
  test04 = ("test04_evalSimple_Mul", evalSimple (Mul (Cst 12) (Cst 2)) == 24)
  test05 = ("test05_evalSimple_Div", evalSimple (Div (Cst 7) (Cst 2)) == 3)
  test06 = ("test06_evalSimple_Pow", evalSimple (Pow (Cst 3) (Cst 2)) == 9)
  test07 = ("test07_evalSimple_PowZero", evalSimple (Pow (Div (Cst 0) (Cst 0)) (Cst 0)) /= 1)


  --test03 = ("test2", evalFull (Let "a" (Cst 42) (Var "a")) initEnv == 42)
  --test04 = ("test3", evalErr (Var "x") initEnv == Left (EBadVar "x"))

main :: IO ()
main =
  let failed = [name | (name, ok) <- tests, not ok]
  in case failed of
       [] -> do putStrLn "All tests passed!"
                exitSuccess
       _ -> do putStrLn $ "Failed tests: " ++ intercalate ", " failed
               exitFailure
