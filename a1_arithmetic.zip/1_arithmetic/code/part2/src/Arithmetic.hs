-- This is a skeleton file for you to edit

module Arithmetic
  (
  showExp,
  evalSimple,
  extendEnv,
  evalFull,
  evalErr,
  showCompact,
  evalEager,
  evalLazy
  )

where

import Definitions


{-
Here the base case would be if the Exp is simply an integer and since 
its a string we use the buildt-in function show (Show a => a -> String)
The rest of the cases are more or less the same except from the unary operation. 
Since we can't be sure what Exp is, we recursively run showExp on Exp until we 
get to the base case. Instead of '/' we are using `div` for division
-}
showExp :: Exp -> String
showExp (Cst e) = "(" ++ show e ++ ")"
showExp (Add e1 e2) = "(" ++ showExp e1 ++ "+" ++ showExp e2 ++ ")"
showExp (Sub e1 e2) = "(" ++ showExp e1 ++ "-" ++ showExp e2 ++ ")"
showExp (Mul e1 e2) = "(" ++ showExp e1 ++ "*" ++ showExp e2 ++ ")"
showExp (Div e1 e2) = "(" ++ showExp e1 ++ "`div`" ++ showExp e2 ++ ")"
showExp (Pow e1 e2) = "(" ++ showExp e1 ++ "^" ++ showExp e2 ++ ")"
showExp _ = error "Not allowed expression"


{-
As with the function above, showExp, if the Exp is an integer it'll 
show the interger.  The rest of the functions works in the same 
fashion as above. Since we don't know what the Exp we recursivly 
check ut Exp with evalSimple until we get to an integer. 

Here `seq` is used to force Haskell to evaluate e1 and then evaluate both e1 and e2. 
This is to make sure that the precedence of computations are done from inside out. 
Furthermore, it also ensures that the expression "0 `div`0 ^ 0" results in an error.
We know that this work since `seq` ensure that if we are evaluating the second argument
then we must also evaluate the first argument.
-}
evalSimple :: Exp -> Integer
evalSimple (Cst e) = e
evalSimple (Add e1 e2) = evalSimple e1 + evalSimple e2 
evalSimple (Sub e1 e2) = evalSimple e1 - evalSimple e2 
evalSimple (Mul e1 e2) = evalSimple e1 * evalSimple e2 
evalSimple (Div e1 e2) = if evalSimple e2 == 0 then error "divsion by zero" else evalSimple e1 `seq`  (evalSimple e1 `div`evalSimple e2)
evalSimple (Pow e1 e2) = if evalSimple e2 < 0 then error "power to negative number" else evalSimple e1 `seq` (evalSimple e1 ^ evalSimple e2)
evalSimple _ = error "Not allowed expression"


{-
This function takes three arguments where the last one is split into two, 
such that, we can compare the new var to an existing var to check if it already exits
in the environment or not. 
-}
extendEnv :: VName -> Integer -> Env -> Env
extendEnv v n r v' = if v == v' then Just n else r v'


{- 
Same as with evalSimple, in principle, but with some added functionalities. 
Those are the If, Let, Sum expressions. In the let expression we make use 
of the function extendEnv to init an v in a env. Sum we evaluate e3 and 
then add the evaluation of sum where we add e1 with 1 
beause we know that in this specific case because each step is only one  
-}
evalFull :: Exp -> Env -> Integer
evalFull = undefined

evalErr :: Exp -> Env -> Either ArithError Integer
evalErr = undefined

-- optional parts (if not attempted, leave them unmodified)

showCompact :: Exp -> String
showCompact e = case e of
  (Cst n) -> show n
  (Add e1 e2) -> showCompact e1 ++ "+" ++ showCompact e2
  (Sub e1 e2) -> showCompact e1 ++ "-" ++ showCompact e2
  (Mul e1 e2) -> showCompact e1 ++ "*" ++ showCompact e2
  (Div e1 e2) -> showCompact e1 ++ "`div`" ++ showCompact e2
  (Pow e1 e2) -> showCompact e1 ++ "^" ++ showCompact e2
  _ -> error "Not allowed expression"

needParentheses :: Exp -> String
needParenthese 

evalEager :: Exp -> Env -> Either ArithError Integer
evalEager = undefined

evalLazy :: Exp -> Env -> Either ArithError Integer
evalLazy = undefined
